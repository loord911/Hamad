
# US Stock AI Agent Desk — v1

## الهدف
نظام بحث وتحليل للأسهم الأمريكية بأسلوب multi-agent:
- 14 وكيل تحليلي حتمي (technical/risk/regime)
- 3 مراجعين LLM اختياريين عند إضافة OpenAI API key
- Master Decision يجمع النتائج
- لا يوجد تنفيذ أوامر حقيقي في هذه النسخة

## التشغيل
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

لتمكين طبقة LLM:
```bash
export OPENAI_API_KEY="..."
export OPENAI_MODEL="gpt-5.6-luna"
```

## مهم
هذه ليست استراتيجية مثبتة الربحية. قبل أي تداول حقيقي نحتاج:
1. Backtest زمني بدون look-ahead/data leakage.
2. Out-of-sample test.
3. Walk-forward validation.
4. Benchmark مقابل Buy & Hold.
5. قياس Sharpe/Sortino/Max Drawdown/Profit Factor.
6. احتساب العمولة والانزلاق السعري.
7. Paper trading قبل التنفيذ الحقيقي.

## التطوير التالي المقترح
- إضافة بيانات أخبار حقيقية ومؤشرات السوق/القطاع.
- إضافة وكيل Fundamental وSEC filings.
- بناء Backtest engine.
- حفظ كل قرار مع timestamp حتى لا نستطيع تعديل الماضي.
- اختبار 15 وكيل مقابل 30/60/89 لمعرفة هل زيادة العدد تضيف قيمة فعلاً.
- بعد إثبات edge فقط: ربط وسيط للتنفيذ.
